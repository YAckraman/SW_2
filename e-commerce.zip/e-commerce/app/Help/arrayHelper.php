<?php

if(! function_exists("roles"))
{
	function role($id = null)
	{
		$array = [
			trans('admin.user'),
			trans('admin.admin')
			
		];

		/// here we put admin.user in the fisrt because we make it 0 index that the default of any user but 
		// the check field in the DB called isAdmin we make the admin.admin the second in the array to get the index 1 and is putting in the DB with 1 to make defferece between admin and user
		return $id == null ? $array : $array[$id];
	}
}