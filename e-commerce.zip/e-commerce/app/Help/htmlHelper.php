<?php

if( !function_exists('editBtn'))
{
	 function editBtn($url)
	 {
	 	return '<a href="'.$url.'" class="btn btn-primary"><i class="fa fa-edit"></i></a>';
	 }
}