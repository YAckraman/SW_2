<?php

//define
use \App\Setting as setting;

//functions

if(!function_exists('getSetting'))
{
	 function getSetting($name = 'site_title')
	 {
	 	$setting = setting::where('name',$name)->first();
	 	return $setting == null ? $name : $setting->real_value;
	 }
}