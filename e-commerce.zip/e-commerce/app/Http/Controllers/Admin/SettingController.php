<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\setting;
class SettingController extends Controller
{
    public function index()
    {
    	$setting = setting::orderby('sorting_number')->get();
    	return view('admin.setting.index',compact('setting'));
    }

    

    public function update(Request $request)
    {
    	foreach ($request->toArray() as $name => $value) {
    		Setting::where('name',$name)->firstOrFail()->update(['value'=>$value]);
            
    	}
    	return back()->withFalshMessage(trans('admin.updated'));
    }
}
