<?php

namespace App\Http\Controllers\Admin;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\User as userRequest;
use DataTables;
use App\User;
use App\setting;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.user.index');
    }

    // Ajax function
    public function loadData(User $user)
    {
        $users = $user->all();
        return DataTables::of($users)
        ->rawColumns(['action'])
        ->editColumn('action',function($model){
            $edit = editBtn(route('user.edit',$model->id));
            return $edit;
        })
        ->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(userRequest $request)
    {
        User::create($request->all());
        return redirect(route('user.index'))->withFalshMessage(trans('created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('admin.user.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(userRequest $request, $id)
    {
        $user = User::findOrFail($id);
        $user->update($request->all());
        return redirect(route('user.index'))->withFalshMessage(trans('updated'));
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function password($id,Request $request)
    {
        $request->validate(['password', 'required|string|min:8']);
        $user = User::findOrFail($id);
        $user->update(['password'=>$request->password]);
        return redirect()->back()->withFalshMessage(trans('updated'));
    }
}
