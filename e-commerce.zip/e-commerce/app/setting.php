<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class setting extends Model
{
    protected $table = 'settings';
    protected $fillable = [
    	'name','title','value',	'type','option','sorting_number'
    ];

    public function getOptionAttribute()
    {
    	$array = [];
    	if($this->attributes['option'] != null)
    		$array = explode(',', $this->attributes['option']);
    	return $array;
    }
    public function getRealValueAttribute()
    {
        $array = $this->option;
        
        return $array == [] ? $this->attributes['value'] : $array[$this->attributes['value']];
    }

    public function getTitleAttribute()
    {
    	return trans('admin.'.$this->attributes['title']);
    }
}
