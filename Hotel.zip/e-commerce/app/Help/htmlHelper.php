<?php

if( !function_exists('editBtn'))
{
	 function editBtn($url)
	 {
	 	return '<a href="'.$url.'" class="btn btn-primary"><i class="fa fa-edit"></i></a>';
	 }
}

if( !function_exists('deleteBtn'))
{
	 function deleteBtn($url)
	 {
	 	return '<a href="'.$url.'" class="btn btn-danger"><i class="fa fa-trash"></i></a>';
	 }
}

if( !function_exists('showBtn'))
{
	 function showBtn($url)
	 {
	 	return '<a href="'.$url.'" class="btn btn-info"><i class="fa fa-eye"></i></a>';
	 }
}