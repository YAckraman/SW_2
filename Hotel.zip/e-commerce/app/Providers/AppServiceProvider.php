<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facadas\Schema;
use View;
use Auth;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
       // Schema::defaultStringLength(191);

        $path='public/panel';
        View::share('css_path',$path.'/css');
        View::share('js_path',$path.'/js');
        View::share('img_path',$path.'/img');
        View::share('plugin_path',$path.'/plugins');

        View()->composer('*',function($View){

            $user = Auth::user();
            $View->with('auth',$user);
        });
    }
}
