<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    protected $tablename = 'posts';
    public $primarykey = 'id';
    public $timestamp = true;
}
