<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Room;
use App\Contact;
use App\User;
class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('Customer.customer.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        if($request->get('book') == 'Book')
        {
            $test = $request->get('rooms');
            $test2 = $request->get('username');
            $test3 = $request->get('email');
            $test4 = $request->get('num_of_room');
            $test5 = $request->get('num_of_guest');
            //return dd($test);
            $req  = Room::create([
                'username' => $test2,
                'email' => $test3,
                'option' => $test,
                'num_of_rooms' => $test4,
                'num_of_guest' => $test5
            ]);
        }
        else
         {
            Contact::create($request->all());
            
        }
        //return dd($request->all());
        
        return View('Customer.customer.index')->withFlashMessage(trans('admin.test'));
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::all();
        return view('Customer.customer.reserve',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
