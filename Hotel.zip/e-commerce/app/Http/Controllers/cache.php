<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class cache extends Controller
{
    public function test()
    {
        Cache::ShouldReceive('get')
                ->with('key')
                ->andReturn('value');

                $this->visit('/cache')
                ->see('value');


                return Cache::get('key');

    }
}
