<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class User extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $array = [];
        if($this->get('id') != null) {
            $array = [


            'username'  => ['required', 'string', 'max:60','unique:users,username,'.$this->get('id')],
            'email'     => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$this->get('id')],

            //this or this is true but it should be unique:users,username, takcare about the , between the users and the get id
            // 'username'  => 'required|string|max:60|unique:users,username,'.$this->get('id'),
            // 'email'     => 'required|string|email|max:255|unique:users,email,'.$this->get('id'),

            

            ];

        }
        else{
            $array = [

            'username'  => ['required', 'string', 'max:60','unique:users'],
            'email'     => ['required', 'string', 'email', 'max:255', 'unique:users'],
            

            ];
        }
        return $array;
    }
}
