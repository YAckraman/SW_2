@extends('layouts.app')
@extends('login_admin2')
@section('navbar')
@endsection
@section('content')
@endsection
<!-- <link href="{{ asset('../../bootstraps/bootstraps.min.css') }}" rel="stylesheet">
     <script src="{{ asset('../../bootstraps/jquery-3.4.1.min.js') }}">
    <script src="{{ asset('../../bootstraps/popper.min.js') }}">
    <script src="{{ asset('../../bootstraps/bootstraps.min.js') }}">  -->
   