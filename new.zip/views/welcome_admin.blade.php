<div style="float:right;margin:10px;">
    <a href="{{ url('admin/logout') }}">Logout</a>
</div>
<center>
    <h1>welocme {{auth()->guard('webadmin')->user()->name}}
</center>