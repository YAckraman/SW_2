@extends('admin.layouts.master')

@section('content')
	<div style="margin-left:400px;margin-top: 250px;">
			<a href="{{route('user.create')}}" class="btn btn-primary"><i class="fa fa-plus" style="width: 100px;"></i></a>
			<a href="{{route('user.index')}}" class="btn btn-info"><i class="fa fa-eye" style="width: 100px;"></i></a>
	</div>

@endsection


@section('title')Mohamed @endsection



