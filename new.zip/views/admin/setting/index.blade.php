@extends('admin.layouts.master')
@section('title') {{trans('admin.setting')}}@endsection

@section('content')




<div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">{{trans('admin.setting')}}</h3>
              </div>
              <!-- /.card-header -->
              {!!
              	Form::open([

              		'url' => route('setting.update'),
              		'method' => 'POST',
              		'role' => 'form'
              	])
              	!!}

              	@foreach($setting as $set)
              <div class="form-group">
              	<label for="{{$set->name}}">{{$set->title}}</label>
              		@if($set->type == 'text')
              			{!! Form::text($set->name,$set->value,[

              				'class' => 'form-control',
              				'placeholder' => $set->title

              				]) !!}
              		@elseif($set->type == 'textarea')
              		{!! Form::texterea($set->name,$set->value,[

              				'class' => 'form-control',
              				'placeholder' => $set->title

              				]) !!}
              		@else
              		{!! Form::select($set->name,$set->option,$set->value,[
              				'class' => 'form-control'
              				]) !!}   
              				<!-- here the option is the value of the EGP OR USD 
              					 the value is the value in the select 

              					 <select name='test'>
              					 	<option value='1'>EGP</option>
              					 	<option value='0'>USD</option>
              					 </select>
              					  -->
              		@endif
              </div>
              	@endforeach
              	<div class="card-footer">
                  <button type="submit" class="btn btn-primary">{{trans('admin.submit')}}</button>
                </div>

              	{!! Form::close()!!}
              
            </div>
            <!-- /.card -->

           

          </div>
     </div>

@endsection