@extends('admin.layouts.master')
@section('title') {{trans('admin.show',['name'=>trans('admin.user')])}}@endsection

@section('content')

<div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">{{trans('admin.show',['name'=>trans('admin.user')])}}</h3>
              </div>

                    <div class="form-group">
                  <div class="card">
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                
                 <tbody>
                    <tr>
                      <th>{{ trans('admin.id') }}</th>
                      <th>{{ $user->id }}</th>
                    </tr>
                    <tr>
                      <th>{{ trans('admin.name') }}</th>
                      <th>{{ $user->name }}</th>
                    </tr>
                    <tr>
                      <th>{{ trans('admin.email') }}</th>
                      <th>{{ $user->email }}</th>
                    </tr>
                    <tr>
                      <th>{{ trans('admin.action') }}</th>
                      <th>{!! editBtn(route('user.edit',$user->id)).' '.
                             deleteBtn(route('user.delete',$user->id)) !!}</th>
                    </tr>
                
                </tbody>
               
              </table>
            </div>
            <!-- /.card-body -->
          </div>  
              
            </div>
              
            
              
            </div>
            <!-- /.card -->

           

          </div>
     </div>

@endsection