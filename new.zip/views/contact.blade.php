@extends('layouts.test')

@section('putContent')
<div class="boy">Contact</div>
    
  <form>
        <div class="form-group">
            <label for="name">Name</label>
            <input type='text' class="form-control" id="name">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type='email' class="form-control" id="email">
        </div>
        <div class="form-group">
        <textarea class="form-control" placeholder="Your message..." rows="4" ></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class=" btn btn-primary"> Send</button>
        </div>
</form>
@endsection