<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="bootstraps/css/bootstrap.min.css">
        <link rel="stylesheet" href="bootstraps/css/test.css">
        <link rel="stylesheet" href="bootstraps/css1/test.css">
        <link rel="stylesheet" href="bootstraps/css1/boy1.css">
        <link rel="stylesheet" href="bootstraps/css1/reserve.css">
        <title>Golden Q </title>

    </head>
    <body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <!-- in the href put the link of the home page  -->
        <a class="navbar-brand" href="{{ url('/home') }}">Golden Q</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ml-auto first">
                <li class="nav-item-active">
                    <a class="nav-link" href="{{url('home')}}">Home<span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('reserve') }}">Room Booking<span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url('contact') }}">Contact<span class="sr-only"></span></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="{{ route('register') }}">Create Account<span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('login') }}">Sign IN<span class="sr-only"></span></a>
                </li>

                <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                   {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                
            </ul>					
        </div>
    </nav>

    @yield('putContent')

    <footer class="tm-footer">
        <div class="tm-us">
        <p class="bold">About Us</p>
        <p>we are a part of helwan unversity and we hope get your like</p>    
        </div>
        <div class="tm-address">
        <p class="bold">Address</p>
        <p>Helwan unversity, Egypt<br>
            Phone : 01287480738<br>
            Email : mohamedgemmyhamzagaber@gmail.com</p>    
        </div>
        <br/>
        <div class="tm-media">
            <a href="#"> <img src="bootstraps/images/fb.png"></a>
            <a href="#"> <img src="bootstraps/images/G.png"> </a>
            <a href="#"> <img src="bootstraps/images/twittr.png"> </a>
            <a href="#">  <img src="bootstraps/images/insta.png"> </a>
        </div>
    </footer>


        <script src="bootstraps/js/jquery-3.4.1.min.js"></script>
        <script src="bootstraps/js/poppor.min.js"></script>
        <script src="bootstraps/js/bootstrap.min.js"></script>
    </body>
</html>