@extends('layouts.test') 

<!-- 

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in {{auth()->user()->username}}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
 -->


@section('putContent')

<div id="slide" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#slide" data-slide-to="0" class="active"></li>
              <li data-target="#slide" data-slide-to="1"></li>
              <li data-target="#slide" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="bootstraps/images/21.jpg" class="d-block w-100" alt="" style="height: 400px;">
                       
                  </div>
                  <div class="carousel-item">
                    <img src="bootstraps/images/luxorius.png" class="d-block w-100" alt="" style="height: 400px;">
                   
                  </div>
                  <div class="carousel-item">
                    <img src="bootstraps/images/main_slider11.png" class="d-block w-100" alt="">
                    
                  </div>
            </div>
            <a class="carousel-control-prev" href="#slide" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#slide" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
        </div>
          
       <div class="col-12 room">Room</div>

        <div class="col-4 test">
        <div class="card " style="width: 18rem;">
            <img class="card-img-top" src="bootstraps/images/luxury.png" alt="test">
            <div class="card-body">
                <h5 class="card-title">Single Room</h5>
                <p class="card-text">this room for one person with bathroom and televsion </p>
                <a href="#" class="btn btn-primary">See More</a>
            </div>
            </div>
            </div>
            <div class="col-4 test" >
                <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="bootstraps/images/luxury.png" alt="test">
                    <div class="card-body">
                        <h5 class="card-title">Double Room</h5>
                        <p class="card-text">this room for two person like Newlywed with bathroom and televsion </p>
                        <a href="#" class="btn btn-primary">See More</a>
                    </div>
                </div>
            </div>
            <div class="col-4 test">
                <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="bootstraps/images/luxury.png" alt="test">
                    <div class="card-body">
                    <h5 class="card-title">Triple Room</h5>
                    <p class="card-text">this room for family or three person with bathroom and televsion </p>
                    <a href="#" class="btn btn-primary">See More</a>
                </div>
            </div>
            </div>

            <div class="clean"></div>
            <div class="test2"></div>

            <div class="col-4 test">
        <div class="card " style="width: 18rem;">
            <img class="card-img-top" src="bootstraps/images/luxury.png" alt="test">
            <div class="card-body">
                <h5 class="card-title">Quad Room</h5>
                <p class="card-text">this room for family or four person with bathroom and televsion and more facilities for family </p>
                <a href="#" class="btn btn-primary">See More</a>
            </div>
            </div>
            </div>
            <div class="col-4 test" >
                <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="bootstraps/images/luxury.png" alt="test">
                    <div class="card-body">
                        <h5 class="card-title">Suite</h5>
                        <p class="card-text">Suite with salon and connect with bedroom or more with beauty view</p>
                        <a href="#" class="btn btn-primary">See More</a>
                    </div>
                </div>
            </div>
            <div class="col-4 test">
                <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="bootstraps/images/luxury.png" alt="test">
                    <div class="card-body">
                    <h5 class="card-title">Room with landview</h5>
                    <p class="card-text">this room for one person or two with bathroom,televsion and with very beautifull landview </p>
                    <a href="#" class="btn btn-primary">See More</a>
                </div>
            </div>
            </div>

            
            <div class="clean"></div>
            <div class="test2"></div>
@endsection
