<?php

Route::get('/reserve',function(){
	return view('reserve');
});
Route::get('/contact',function(){
	return view('contact');
});

Route::get('/login',function(){
	return view('layouts.app');
});
Route::get('/register',function(){
	return view('layouts.app');
});
