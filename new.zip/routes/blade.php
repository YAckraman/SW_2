<?php

Blade::directive('test',function($val){
    if($val == 2019)
        return '<a href="#">Click here</a> this is '.$val;
    else
        return 'welcome';
});