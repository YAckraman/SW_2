<?php

//Ajax
//User

Route::get('/loadUserData','UserController@loadData')->name('admin.user.data');

//load 

Route::get('/','HomeController@index')->name('admin.home');

//settings

Route::get('/setting','SettingController@index')->name('setting.index');
Route::post('/setting','SettingController@update')->name('setting.update');


//User

Route::resource('/user','UserController');
Route::get('user/{id}/delete','UserController@confirmation')->name('user.delete');

Route::PATCH('user/{id}/password','UserController@password')->name('user.password');






